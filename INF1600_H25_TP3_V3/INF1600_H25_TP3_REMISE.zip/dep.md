### fedora
sudo dnf install libstdc++-devel libstdc++-devel.i686
sudo dnf install mesa-libGL.i686 mesa-libGLU.i686 libX11.i686 libXcursor.i686 libXrandr.i686 libXi.i686 libXinerama.i686 libXxf86vm.i686 libX11-devel.i686 libXrandr-devel.i686 libXi-devel.i686 libXinerama-devel.i686 libXcursor-devel.i686 alsa-lib-devel.i686

### Ubuntu
sudo apt update
sudo apt install libgl1-mesa-glx:i386 libglu1-mesa:i386 libx11-6:i386 libxcursor1:i386 libxrandr2:i386 libxi6:i386 libxinerama1:i386 libxxf86vm1:i386